# eks-cluster
# Resource for create EKS cluster
# For Terraform 0.11.13
1. Pre-requirement
- VPC
- SGs
- IAM roles
- S3 Buckets(for backend.tf and remote state)
2. Usage
Terraform directory
```bash
.
├── source
│   ├── eks.tf
│   ├── provider.tf
│   └── variables.tf
└── stg-seoul
    ├── backend.tf
    ├── eks.tf -> ../source/eks.tf
    ├── output.tf
    ├── provider.tf -> ../source/provider.tf
    ├── remote_state.tf
    ├── terraform.tfvars
    └── variables.tf -> ../source/variables.tf
```
- Apply terraform
- Add oidc provider of cluster to trusted relationship of iam role eks_node
